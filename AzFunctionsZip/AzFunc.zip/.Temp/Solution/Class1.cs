﻿using System;

namespace dummy
{
    public class Class1
    {
    }
}
