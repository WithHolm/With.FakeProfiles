using namespace System.Net
using namespace Microsoft.Azure
using namespace Microsoft.Azure.Storage
using namespace Microsoft.Extensions.Configuration
using namespace Microsoft.Extensions.Configuration.AzureAppConfiguration
# Input bindings are passed in via param block.
param(
    [Microsoft.Azure.Functions.PowerShellWorker.HttpRequestContext]$Request, 
    [hashtable]$TriggerMetadata,
    $starter
)

ipmo (join-path (split-path $PSScriptRoot) "AzFnHelp") -Force
$Body = [ordered]@{
    TimeStamp = [datetime]::Now
    message = "Error with http request"
}
$StatusCode = [System.Net.HttpStatusCode]::BadRequest
Write-Host "PowerShell HTTP trigger function processed a request."

gci env:

if($Request.Method -eq "GET")
{
    $Body = [ordered]@{
        TimeStamp = [datetime]::Now
        message = "OK"
    }
    $StatusCode = [System.Net.HttpStatusCode]::OK
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = $StatusCode
        Body       = $Body
    })
}
elseif($Request.Method -eq "POST") {
    $JobTable = Get-FnTableFast -Name "jobs" -Connectionstring $env:AzureWebJobsStorage -CreateIfNotExist
    if($Request.Query.Job)
    {

        # if(Set-FnSingletonFlag -Enable -Name "ProcessFace" -ConnectionString $env:AzureWebJobsStorage)
        # {
        #     Get-AzTableRow -Table $Table -Operator "PartitionKey eq ''"
        #     $StopProcess = $false
        #     While($StopProcess -eq $false)
        #     {
                
        
        #         # Write-Information "Sleeping 30 sec" -Tags "Test"
        #         $StopProcess = $false
        #     }
        #     Set-FnSingletonFlag -Disable -Name "ProcessFace" -ConnectionString $env:AzureWebJobsStorage
        #     # if(Get-AzTableRow -Table $Table -Operator "PartitionKey eq ''" )
        # }
    }
    elseif($Request.Query.Count)
    {
        Write-Information "Adding $($Request.Query.Count) to jobtable"
        $ID = [Guid]::NewGuid().Guid
        $Property = @{
            Source = ""
            Comment = "Request: $($Request.Query.Count)"
            Value = [int]$Request.Query.Count
            Tag = "Waiting"
            Completed = $false
        }
        [void](Add-AzTableRow -PartitionKey "GenerateImage" -RowKey $ID -property $Property -Table $JobTable)

        $Body = [ordered]@{
            TimeStamp = [datetime]::Now
            ID = $ID
            message = "Added request to generate $($Request.Query.Count) images"
        }
        # Write-Verbose ""
        $StatusCode = [System.Net.HttpStatusCode]::OK
        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = $StatusCode
            Body       = $Body
        })
        # Invoke-Command -ScriptBlock {Invoke-WebRequest -Uri "http://myurl.com" -Method Post} -AsJob
    }
}
# Get-OutputBinding
# command Push-OutputBinding

# Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
#     StatusCode = $StatusCode
#     Body       = $Body
# })
