function Update-JobItem {
    [CmdletBinding()]
    param (
        [Microsoft.Azure.Cosmos.Table.CloudTable]$Table
        # []
    )
    
    begin {
        
    }
    
    process {
        
    }
    
    end {
        
    }
}